<?php

/**
 * Product query builder shared by search and facets.
 *
 * @package BePlusFastProductFilterLiveSearch
 * @subpackage Search
 */

namespace BePlusFastProductFilterLiveSearch\Search;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Builds wc_get_products arguments from SearchQuery.
 */
final class ProductQueryBuilder {

	/**
	 * Build wc_get_products args.
	 *
	 * @param SearchQuery          $query     Search query.
	 * @param array<string, mixed> $overrides Optional overrides (limit, paginate, return).
	 *
	 * @return array<string, mixed>
	 */
	public static function build_args( SearchQuery $query, array $overrides = array() ): array {
		$args = array(
			'status'   => 'publish',
			'limit'    => $query->get_per_page(),
			'page'     => $query->get_page(),
			'paginate' => true,
			'return'   => 'objects',
			'orderby'  => self::map_orderby( $query->get_orderby() ),
			'order'    => strtoupper( $query->get_order() ),
		);

		if ( $query->get_keyword() ) {
			if ( SearchFieldsFilter::should_apply( $query ) ) {
				$args[ SearchFieldsFilter::QUERY_FLAG ] = true;
			} else {
				$args['s'] = $query->get_keyword();
				if ( KeywordSearchFilter::should_apply( $query ) ) {
					$args[ KeywordSearchFilter::QUERY_FLAG ] = true;
				}
			}
		}

		$tax_query = array();

		$cats = $query->get_product_cats();
		if ( ! empty( $cats ) ) {
			$tax_query[] = array(
				'taxonomy' => 'product_cat',
				'field'    => 'slug',
				'terms'    => $cats,
				'operator' => 'IN',
			);
		}

		$tags = $query->get_product_tags();
		if ( ! empty( $tags ) ) {
			$tax_query[] = array(
				'taxonomy' => 'product_tag',
				'field'    => 'slug',
				'terms'    => $tags,
				'operator' => 'IN',
			);
		}

		foreach ( $query->get_attributes() as $attr_slug => $term_slugs ) {
			$taxonomy = wc_attribute_taxonomy_name( $attr_slug );
			if ( ! taxonomy_exists( $taxonomy ) || empty( $term_slugs ) ) {
				continue;
			}
			$tax_query[] = array(
				'taxonomy' => $taxonomy,
				'field'    => 'slug',
				'terms'    => $term_slugs,
				'operator' => 'IN',
			);
		}

		foreach ( $query->get_taxonomies() as $taxonomy => $term_slugs ) {
			if ( ! taxonomy_exists( $taxonomy ) || empty( $term_slugs ) ) {
				continue;
			}
			$tax_query[] = array(
				'taxonomy' => $taxonomy,
				'field'    => 'slug',
				'terms'    => $term_slugs,
				'operator' => 'IN',
			);
		}

		self::append_min_rating_tax_query( $tax_query, $query->get_min_rating() );

		if ( ! empty( $tax_query ) ) {
			if ( count( $tax_query ) > 1 ) {
				$tax_query['relation'] = 'AND';
			}
			$args['tax_query'] = $tax_query; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- Required for WooCommerce product filtering.
		}

		if ( $query->get_stock_status() ) {
			$args['stock_status'] = $query->get_stock_status();
		}

		if ( $query->is_on_sale() ) {
			if ( function_exists( 'wc_get_product_ids_on_sale' ) ) {
				$on_sale_ids = wc_get_product_ids_on_sale();
				if ( empty( $on_sale_ids ) ) {
					$args['include'] = array( -1 );
				} else {
				$args['include'] = isset( $args['include'] ) // @phpstan-ignore isset.offset
					? array_intersect( (array) $args['include'], $on_sale_ids )
					: $on_sale_ids;
				}
				$args['bpss_on_sale'] = true;
			}
		}

		if ( $query->is_featured() ) {
			$args['featured'] = true;
		}

		if ( $query->get_min_price() > 0 ) {
			$args['min_price'] = (string) $query->get_min_price();
		}

		if ( $query->get_max_price() > 0 ) {
			$args['max_price'] = (string) $query->get_max_price();
		}

		if ( $query->get_min_price() > 0 || $query->get_max_price() > 0 ) {
			$args[ PriceQueryFilter::QUERY_FLAG ] = true;
		}

		return array_merge( $args, $overrides );
	}

	/**
	 * Append WooCommerce product_visibility rated-* terms for minimum rating.
	 *
	 * wc_get_products ignores meta_query; visibility terms match WC layered nav.
	 *
	 * @param array<int|string, mixed> $tax_query  Tax query clauses (by reference).
	 * @param float                    $min_rating Minimum average rating (1-5).
	 *
	 * @return void
	 */
	private static function append_min_rating_tax_query( array &$tax_query, float $min_rating ): void {
		if ( $min_rating <= 0 || ! function_exists( 'wc_get_product_visibility_term_ids' ) ) {
			return;
		}

		$min            = max( 1, min( 5, (int) $min_rating ) );
		$visibility_ids = wc_get_product_visibility_term_ids();
		$rated_terms    = array();

		for ( $i = 5; $i >= $min; $i-- ) {
			$key = 'rated-' . $i;
			if ( ! empty( $visibility_ids[ $key ] ) ) {
				$rated_terms[] = (int) $visibility_ids[ $key ];
			}
		}

		if ( empty( $rated_terms ) ) {
			$tax_query[] = array(
				'taxonomy' => 'product_visibility',
				'field'    => 'term_taxonomy_id',
				'terms'    => array( 0 ),
				'operator' => 'IN',
			);
			return;
		}

		$tax_query[] = array(
			'taxonomy' => 'product_visibility',
			'field'    => 'term_taxonomy_id',
			'terms'    => $rated_terms,
			'operator' => 'IN',
		);
	}

	/**
	 * Execute wc_get_products with optional price filter clauses.
	 *
	 * @param SearchQuery          $query     Search query.
	 * @param array<string, mixed> $overrides Optional overrides.
	 *
	 * @return object|array<int, mixed>
	 */
	public static function query( SearchQuery $query, array $overrides = array() ) {
		$args = self::build_args( $query, $overrides );
		self::apply_wc_catalog_ordering( $query, $args );

		$price_filter   = null;
		$keyword_filter = null;
		$fields_filter  = null;
		if ( ! empty( $args[ PriceQueryFilter::QUERY_FLAG ] ) ) {
			$price_filter = new PriceQueryFilter();
			add_filter( 'posts_clauses', array( $price_filter, 'add_clauses' ), 10, 2 );
		}

		if ( ! empty( $args[ SearchFieldsFilter::QUERY_FLAG ] ) ) {
			$fields_filter = SearchFieldsFilter::register( $query );
		} elseif ( ! empty( $args[ KeywordSearchFilter::QUERY_FLAG ] ) ) {
			$keyword_filter = new KeywordSearchFilter( $query );
			add_filter( 'posts_search', array( $keyword_filter, 'filter_search' ), 10, 2 );
		}

		try {
			return self::query_via_wp_query( $args );
		} finally {
			if ( $price_filter ) {
				remove_filter( 'posts_clauses', array( $price_filter, 'add_clauses' ), 10 );
			}
			if ( $fields_filter ) {
				$fields_filter->unregister();
			}
			if ( $keyword_filter ) {
				remove_filter( 'posts_search', array( $keyword_filter, 'filter_search' ), 10 );
			}
			self::clear_wc_catalog_ordering_filters();
		}
	}

	/**
	 * Execute product query via WP_Query directly (fallback for wc_get_products).
	 *
	 * @param array<string, mixed> $args wc_get_products-style args.
	 *
	 * @return object|array<int, mixed>
	 */
	private static function query_via_wp_query( $args ) {
		$wp_args = array(
			'post_type'      => 'product',
			'post_status'    => isset( $args['status'] ) ? $args['status'] : 'publish',
			'posts_per_page' => isset( $args['limit'] ) ? (int) $args['limit'] : 10,
			'paged'          => isset( $args['page'] ) ? (int) $args['page'] : 1,
			'orderby'        => isset( $args['orderby'] ) ? $args['orderby'] : 'menu_order title',
			'order'          => isset( $args['order'] ) ? $args['order'] : 'ASC',
		);

		if ( ! empty( $args['s'] ) ) {
			$wp_args['s'] = $args['s'];
		}

		if ( ! empty( $args['tax_query'] ) ) {
			$wp_args['tax_query'] = $args['tax_query'];
		}

		if ( ! empty( $args['meta_key'] ) ) {
			$wp_args['meta_key'] = $args['meta_key'];
		}

		if ( ! empty( $args['stock_status'] ) ) {
			if ( 'instock' === $args['stock_status'] ) {
				$wp_args['meta_query'][] = array(
					'relation' => 'OR',
					array(
						'key'     => '_stock_status',
						'value'   => 'instock',
						'compare' => '=',
					),
					array(
						'key'     => '_stock_status',
						'compare' => 'NOT EXISTS',
					),
				);
			} else {
				$wp_args['meta_query'][] = array(
					'key'     => '_stock_status',
					'value'   => $args['stock_status'],
					'compare' => '=',
				);
			}
		}

		if ( ! empty( $args['bpss_on_sale'] ) ) {
			$wp_args['meta_query'][] = array(
				'key'     => '_sale_price',
				'value'   => '',
				'compare' => '!=',
			);
		} elseif ( ! empty( $args['include'] ) ) {
			$wp_args['post__in'] = $args['include'];
		}

		if ( ! empty( $args['featured'] ) ) {
			$visibility_ids = function_exists( 'wc_get_product_visibility_term_ids' )
				? wc_get_product_visibility_term_ids()
				: array();
			if ( ! empty( $visibility_ids['featured'] ) ) {
				$wp_args['tax_query'][] = array(
					'taxonomy' => 'product_visibility',
					'field'    => 'term_taxonomy_id',
					'terms'    => array( $visibility_ids['featured'] ),
				);
			}
		}

		if ( ! empty( $args['product_cats'] ) ) {
			$wp_args['tax_query'][] = array(
				'taxonomy' => 'product_cat',
				'field'    => 'slug',
				'terms'    => $args['product_cats'],
				'operator' => 'IN',
			);
		}

		if ( ! empty( $args['product_tags'] ) ) {
			$wp_args['tax_query'][] = array(
				'taxonomy' => 'product_tag',
				'field'    => 'slug',
				'terms'    => $args['product_tags'],
				'operator' => 'IN',
			);
		}

		if ( ! empty( $args[ PriceQueryFilter::QUERY_FLAG ] ) ) {
			$min_price = isset( $args['min_price'] ) ? (float) $args['min_price'] : 0;
			$max_price = isset( $args['max_price'] ) ? (float) $args['max_price'] : 0;

			if ( $min_price > 0 && $max_price > 0 ) {
				$wp_args['meta_query'][] = array(
					'relation' => 'AND',
					self::price_range_clause( $min_price, '>=' ),
					self::price_range_clause( $max_price, '<=' ),
				);
			} elseif ( $min_price > 0 ) {
				$wp_args['meta_query'][] = self::price_range_clause( $min_price, '>=' );
			} elseif ( $max_price > 0 ) {
				$wp_args['meta_query'][] = self::price_range_clause( $max_price, '<=' );
			}
		}

		if ( ! empty( $args[ SearchFieldsFilter::QUERY_FLAG ] ) ) {
			$wp_args[ SearchFieldsFilter::QUERY_FLAG ] = true;
			$wp_args['suppress_filters']              = false;
		}

		if ( ! empty( $args[ KeywordSearchFilter::QUERY_FLAG ] ) ) {
			$wp_args[ KeywordSearchFilter::QUERY_FLAG ] = true;
			$wp_args['suppress_filters']                = false;
		}

		if ( ! empty( $args[ PriceQueryFilter::QUERY_FLAG ] ) ) {
			$wp_args[ PriceQueryFilter::QUERY_FLAG ] = true;
		}

		$query  = new \WP_Query( $wp_args );
		$return = isset( $args['return'] ) ? $args['return'] : 'objects';
		$paginate = isset( $args['paginate'] ) ? $args['paginate'] : true;

		if ( 'ids' === $return ) {
			$products = wp_list_pluck( $query->posts, 'ID' );
		} else {
			$products = array_filter( array_map( 'wc_get_product', $query->posts ) );
		}

		if ( $paginate ) {
			return (object) array(
				'products'      => $products,
				'total'         => $query->found_posts,
				'max_num_pages' => $query->max_num_pages,
			);
		}

		return $products;
	}

	/**
	 * Build a price meta query clause that checks _price, _regular_price, and _sale_price.
	 *
	 * @param float  $price   Price threshold.
	 * @param string $compare >= or <=.
	 *
	 * @return array<string|int, mixed>
	 */
	private static function price_range_clause( float $price, string $compare ): array {
		return array(
			'relation' => 'OR',
			self::single_price_clause( '_price', $price, $compare ),
			self::single_price_clause( '_regular_price', $price, $compare ),
			self::single_price_clause( '_sale_price', $price, $compare ),
		);
	}

	/**
	 * Build a single price meta clause.
	 *
	 * @param string $key     Meta key.
	 * @param float  $price   Price threshold.
	 * @param string $compare >= or <=.
	 *
	 * @return array<string, mixed>
	 */
	private static function single_price_clause( string $key, float $price, string $compare ): array {
		return array(
			'key'     => $key,
			'value'   => $price,
			'compare' => $compare,
			'type'    => 'DECIMAL',
		);
	}

	/**
	 * Apply WooCommerce catalog ordering (price, popularity, rating, etc.).
	 *
	 * @param SearchQuery          $query Search query.
	 * @param array<string, mixed> $args  wc_get_products args (by reference).
	 *
	 * @return void
	 */
	private static function apply_wc_catalog_ordering( SearchQuery $query, array &$args ): void {
		if ( ! function_exists( 'WC' ) || ! WC()->query ) {
			return;
		}

		$ordering = WC()->query->get_catalog_ordering_args(
			$query->get_orderby(),
			strtoupper( $query->get_order() ),
		);

		$args['orderby'] = $ordering['orderby'];
		$args['order']   = $ordering['order'];

		if ( ! empty( $ordering['meta_key'] ) ) {
			$args['meta_key'] = $ordering['meta_key']; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- WooCommerce catalog ordering.
		}
	}

	/**
	 * Remove WC_Query posts_clauses callbacks registered by get_catalog_ordering_args().
	 *
	 * @return void
	 */
	private static function clear_wc_catalog_ordering_filters(): void {
		if ( ! function_exists( 'WC' ) || ! WC()->query ) {
			return;
		}

		$wc_query  = WC()->query;
		$callbacks = array(
			'order_by_price_asc_post_clauses',
			'order_by_price_desc_post_clauses',
			'order_by_popularity_post_clauses',
			'order_by_rating_post_clauses',
		);

		foreach ( $callbacks as $callback ) {
			remove_filter( 'posts_clauses', array( $wc_query, $callback ) );
		}
	}

	/**
	 * Count products matching query.
	 *
	 * @param SearchQuery $query Search query.
	 *
	 * @return int
	 */
	public static function count( SearchQuery $query ): int {
		if ( ! function_exists( 'wc_get_products' ) ) {
			return 0;
		}

		$result = self::query(
			$query,
			array(
				'limit'    => 1,
				'page'     => 1,
				'paginate' => true,
				'return'   => 'ids',
			),
		);

		return isset( $result->total ) ? (int) $result->total : 0;
	}

	/**
	 * Count published products for a taxonomy term (matches search results).
	 *
	 * @param \WP_Term $term Term object.
	 *
	 * @return int
	 */
	public static function count_for_term( \WP_Term $term ): int {
		static $cache = array();

		$cache_key = $term->taxonomy . ':' . $term->slug;
		if ( isset( $cache[ $cache_key ] ) ) {
			return $cache[ $cache_key ];
		}

		if ( ! function_exists( 'wc_get_products' ) ) {
			$cache[ $cache_key ] = (int) $term->count;
			return $cache[ $cache_key ];
		}

		$args = array();

		if ( 'product_cat' === $term->taxonomy ) {
			$args['product_cats'] = array( $term->slug );
		} elseif ( 'product_tag' === $term->taxonomy ) {
			$args['product_tags'] = array( $term->slug );
		} elseif ( 0 === strpos( $term->taxonomy, 'pa_' ) ) {
			$args['attributes'] = array(
				substr( $term->taxonomy, 3 ) => array( $term->slug ),
			);
		} elseif ( is_object_in_taxonomy( 'product', $term->taxonomy ) ) {
			$args['taxonomies'] = array(
				$term->taxonomy => array( $term->slug ),
			);
		} else {
			$cache[ $cache_key ] = (int) $term->count;
			return $cache[ $cache_key ];
		}

		$count               = self::count( new SearchQuery( $args ) );
		$cache[ $cache_key ] = $count;

		return $count;
	}

	/**
	 * @param string $orderby Order key.
	 *
	 * @return string
	 */
	private static function map_orderby( string $orderby ): string {
		$map = array(
			'menu_order' => 'menu_order',
			'title'      => 'title',
			'price'      => 'price',
			'date'       => 'date',
			'popularity' => 'popularity',
			'rating'     => 'rating',
			'relevance'  => 'relevance',
		);

		return isset( $map[ $orderby ] ) ? $map[ $orderby ] : 'menu_order';
	}
}
