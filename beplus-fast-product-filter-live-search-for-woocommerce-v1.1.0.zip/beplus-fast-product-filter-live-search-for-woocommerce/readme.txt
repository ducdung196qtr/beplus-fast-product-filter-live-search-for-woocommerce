=== Beplus Fast Product Filter & Live Search for WooCommerce ===
Contributors: bearsthemes, ducdung2026
Tags: search, woocommerce, filter, gutenberg
Requires at least: 6.5
Tested up to: 7.0
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Source Code: https://github.com/ducdung196qtr/beplus-fast-product-filter-live-search-for-woocommerce

Fast, smart AJAX product filter & live search for WooCommerce. Instant results, no page reload — more conversions on your shop.

== Description ==

**Beplus Fast Product Filter & Live Search for WooCommerce** provides two powerful Gutenberg blocks to boost product discovery on your WooCommerce store:

* **Advanced Woo Search** — a full-featured filter block with keyword search, category, tag, attributes, price range, stock status, on-sale, featured, and rating filters. Shoppers narrow results instantly with no page reload.
* **Live Search** — a smart autocomplete search bar with dropdown results, inline suggestions, typo correction, AJAX add-to-cart, and highlighted matches.

Drop either block into any shop template built with the Site Editor.

= Why store owners like it =

* **Instant results** — filters and search apply right away, no full page refresh
* **Flexible filters** — keyword, category, tag, attributes, price, stock, rating, and more
* **Two block types** — filter bar + autocomplete search bar, use one or both
* **Fits your layout** — sidebar or horizontal bar, styled to match your theme
* **Built for modern WooCommerce** — works with block themes and the product collection block

= Who it's for =

* WooCommerce stores with medium or large catalogs
* Shops built with the Site Editor (e.g. Twenty Twenty-Five)
* Anyone who wants a cleaner, faster product discovery experience

**Requires WooCommerce.**

= Live Demos =

* **Live Search** — [https://woo-advanced-filter.beplusthemes.com/demo-live-search/](https://woo-advanced-filter.beplusthemes.com/demo-live-search/)
* **Advanced Woo Search (Shop)** — [https://woo-advanced-filter.beplusthemes.com/shop/](https://woo-advanced-filter.beplusthemes.com/shop/)

== Installation ==

1. Upload the plugin to `/wp-content/plugins/beplus-fast-product-filter-live-search-for-woocommerce/`
2. Activate through the 'Plugins' menu in WordPress
3. Requires WooCommerce to be active
4. In Site Editor, edit the shop template and insert the **Advanced Woo Search** or **Live Search** block

For development setup (Node, Composer, build), see `README.md` in the plugin folder.

== Frequently Asked Questions ==

= Does this work with block themes? =

Yes. Both blocks are designed for blockified WooCommerce shop templates (e.g. Twenty Twenty-Five). The Advanced Woo Search block integrates directly with the WooCommerce Product Collection block.

= Can I use only one of the blocks? =

Yes. The Live Search and Advanced Woo Search blocks work independently. You can add just the autocomplete search bar to your header, or just the full filter panel to your shop page, or both.

= Does it support custom taxonomies? =

Yes. In Advanced Woo Search, you can toggle custom taxonomies on or off. Select which attributes to show via the block settings. The Live Search block supports limiting search to specific categories.

= Will this slow down my store? =

No. All filtering and searching happens via AJAX with a built-in cache service. Pages are not reloaded, and search results are cached server-side for fast subsequent queries. You can also configure debounce timing to control request frequency.

= Can I customize the look and feel? =

Yes. Both blocks inherit your theme's styles. The Advanced Woo Search block supports sidebar or inline layout, and you can toggle individual filter sections (keyword, category, price, stock, attributes, etc.). Block spacing and alignment are fully supported.

= Does it work with page builders? =

The blocks are designed for the WordPress Site Editor and block themes. However, they can also be used in any content area that supports Gutenberg blocks.

= Is WooCommerce required? =

Yes. The plugin relies on WooCommerce product data, taxonomies, and templates. It will not activate without WooCommerce installed and active.

= Does it support variable and grouped products? =

Yes. The plugin handles simple, variable, grouped, and external products. Stock filters and price ranges account for variations.

== Changelog ==

= 1.1.0 =
* Renamed plugin from "Beplus Smart Search" to "Beplus Fast Product Filter & Live Search for WooCommerce"
* Improved search performance with server-side caching
* Fixed search not working for products imported after plugin activation
* Added demo links for Live Search and Advanced Woo Search

= 1.0.0 =
* Initial release with Advanced Woo Search and Live Search blocks
* REST API: products, facets, and suggestions endpoints
* Live filtering and autocomplete search without page reload
